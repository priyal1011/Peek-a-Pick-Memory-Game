import 'package:flutter/material.dart';
import 'dart:async';
import 'instructions_page.dart'; // ✅ Navigate to Instructions Page after loading

class LoadingScreen extends StatefulWidget {
  const LoadingScreen({super.key});

  @override
  _LoadingScreenState createState() => _LoadingScreenState();
}

class _LoadingScreenState extends State<LoadingScreen> {
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    precacheImage(AssetImage('assets/images/logo.jpeg'), context);
  }

  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const InstructionsPage()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/images/peek_a_peek.jpg', width: 300, height: 300),
            const SizedBox(height: 20),
            const Text(
              "Pick-A-Peek",
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Color(0xFF222831)),
            ),
            const SizedBox(height: 20),
            const CircularProgressIndicator(color: Color(0xFFF7931E)),
          ],
        ),
      ),
    );
  }
}