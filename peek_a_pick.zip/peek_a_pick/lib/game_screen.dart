import 'package:flutter/material.dart';
import 'dart:async';
import 'instructions_page.dart';

class GameScreen extends StatefulWidget {
  final int gridSize;
  final int timeLimit;

  const GameScreen({Key? key, required this.gridSize, required this.timeLimit}) : super(key: key);

  @override
  _GameScreenState createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  late List<String> cardValues;
  late List<bool> flippedCards;
  int firstIndex = -1, secondIndex = -1, score = 0, timer = 0, highScore = 0;
  Timer? gameTimer;
  bool isChecking = false;
  bool isPaused = false;

  @override
  void initState() {
    super.initState();
    cardValues = generateCards(widget.gridSize);
    flippedCards = List.filled(widget.gridSize * widget.gridSize, false);
    timer = widget.timeLimit;
    startTimer();
  }

  void checkWinCondition() {
    if (!flippedCards.contains(false)) { // All cards are flipped
      gameTimer?.cancel();
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          title: const Text("Congratulations!"),
          content: Text("You won with a score of $score!\nHigh Score: $highScore"),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                resetGame();
              },
              child: const Text("Play Again"),
            ),
          ],
        ),
      );
    }
  }

  void pauseGame() {
    setState(() {
      isPaused = !isPaused;
    });

    if (isPaused) {
      gameTimer?.cancel();
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          title: const Text("Game Paused"),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                setState(() {
                  isPaused = false;
                  startTimer();
                });
              },
              child: const Text("Resume"),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                resetGame();
              },
              child: const Text("Restart"),
            ),
          ],
        ),
      );
    } else {
      startTimer();
    }
  }


  List<String> generateCards(int gridSize) {
    // List<String> symbols = [
    //   "⭐", "🌙", "🔥", "❄", "🍀", "💎", "🎵", "❤",
    //   "⚡", "💡", "🎲", "🛸", "🎭", "🎸", "🎯", "🦄",
    //   "🎷", "🎮", "🎨", "🛍", "🚀", "🔮", "🦊", "🐉"
    // ];

    List<String> symbols = [
      "🌿", "🌸", "🌊", "🍄", "🍁", "🌻", "🌙", "⭐",
      "🦁", "🐯", "🦊", "🐵", "🐼", "🐸", "🐢", "🐍",
      "🎩", "🔮", "🎸", "🎨", "🎭", "🎯", "🎮", "🎷",
      "🍎", "🍩", "🍫", "🍕", "🍔", "🌮", "🍉", "🥑",
      "🚀", "🛸", "🪄", "🌠", "✨", "🔥", "⚡", "💡"
    ];

    int numPairs = (gridSize * gridSize) ~/ 2;
    List<String> selectedSymbols = symbols.sublist(0, numPairs);
    List<String> cardList = [...selectedSymbols, ...selectedSymbols];
    cardList.shuffle();
    return cardList;
  }

  void startTimer() {
    gameTimer?.cancel();
    gameTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted && !isPaused) {
        setState(() {
          if (this.timer > 0) {
            this.timer--;
          } else {
            gameTimer?.cancel();
            showGameOverDialog();
          }
        });
      }
    });
  }

  void checkMatch() {
    isChecking = true;
    if (cardValues[firstIndex] == cardValues[secondIndex]) {
      setState(() {
        score += 10;
        firstIndex = -1;
        secondIndex = -1;
        isChecking = false;
      });
      checkWinCondition();
    } else {
      Future.delayed(const Duration(seconds: 1), () {
        setState(() {
          flippedCards[firstIndex] = false;
          flippedCards[secondIndex] = false;
          firstIndex = -1;
          secondIndex = -1;
          isChecking = false;
        });
      });
    }
  }

  void showGameOverDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text("Game Over"),
        content: Text("Your Score: $score\nHigh Score: $highScore"),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              resetGame();
            },
            child: const Text("Restart"),
          ),
        ],
      ),
    );
  }

  void resetGame() {
    gameTimer?.cancel();
    setState(() {
      cardValues = generateCards(widget.gridSize);
      flippedCards = List.filled(widget.gridSize * widget.gridSize, false);
      firstIndex = -1;
      secondIndex = -1;
      score = 0;
      timer = widget.timeLimit;
      isChecking = false;
      isPaused = false;
    });
    startTimer();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back, color: Color(0xFFF66C47)),
                    onPressed: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => const InstructionsPage()),
                      );
                    },
                  ),
                  Text("High Score: $highScore", style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  IconButton(
                    icon: const Icon(Icons.pause, color: Color(0xFFF66C47)),
                    onPressed: pauseGame,
                  ),
                ],
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.orangeAccent,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text("Score: $score", style: const TextStyle(color: Colors.white, fontSize: 16)),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  decoration: BoxDecoration(
                    color: Color(0xFFF66C47),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text("Timer: ${timer}s", style: const TextStyle(color: Colors.white, fontSize: 16)),
                ),
              ],
            ),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.all(16.0),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: widget.gridSize,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 1.0,
                ),
                itemCount: widget.gridSize * widget.gridSize,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () {
                      if (isChecking || flippedCards[index] || isPaused) return;
                      setState(() {
                        flippedCards[index] = true;
                        if (firstIndex == -1) {
                          firstIndex = index;
                        } else if (secondIndex == -1) {
                          secondIndex = index;
                          checkMatch();
                        }
                      });
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: flippedCards[index] ? Colors.white : Colors.orangeAccent,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Center(
                        child: Text(
                          flippedCards[index] ? cardValues[index] : "?",
                          style: const TextStyle(fontSize: 30, color: Colors.white),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
