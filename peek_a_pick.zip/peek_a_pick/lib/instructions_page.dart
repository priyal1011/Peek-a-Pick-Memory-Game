import 'package:flutter/material.dart';
import 'game_screen.dart';
import 'dart:io';

class InstructionsPage extends StatefulWidget {
  const InstructionsPage({Key? key}) : super(key: key);

  @override
  _InstructionsPageState createState() => _InstructionsPageState();
}

class _InstructionsPageState extends State<InstructionsPage> {
  int selectedGridSize = 4;
  int selectedTimeLimit = 30;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text(
          'Memory Game',
          style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: Colors.orangeAccent,
        elevation: 0,
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.exit_to_app, color: Colors.white),
            onPressed: () => _showExitDialog(context),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
              'assets/images/peek_a_peek.jpg',
              height: 250,
              width: 250,
            ),
            const SizedBox(height: 20),
            const Text(
              "Select grid size",
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: Colors.black),
            ),
            const SizedBox(height: 10),
            _buildSelectionRow([4, 6, 8], selectedGridSize, (value) {
              setState(() => selectedGridSize = value);
            }),
            const SizedBox(height: 20),
            const Text(
              "Select time",
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: Colors.black),
            ),
            const SizedBox(height: 10),
            _buildSelectionRow([30, 60, 90], selectedTimeLimit, (value) {
              setState(() => selectedTimeLimit = value);
            }),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => GameScreen(gridSize: selectedGridSize, timeLimit: selectedTimeLimit),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                backgroundColor: Colors.orangeAccent,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text(
                "Start Game",
                style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: Colors.white),
              ),
            ),
            const SizedBox(height: 10),
            TextButton(
              onPressed: () => _showInstructionsDialog(context),
              child: const Text(
                "Instructions",
                style: TextStyle(fontSize: 17, color: Colors.black, decoration: TextDecoration.underline),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSelectionRow(List<int> options, int selectedValue, ValueChanged<int> onChanged) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: options.map((option) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5),
          child: ChoiceChip(
            label: Text("$option", style: TextStyle(fontSize: 17, color: selectedValue == option ? Colors.white : Colors.black)),
            selected: selectedValue == option,
            selectedColor: Colors.orangeAccent,
            backgroundColor: Colors.grey[300],
            onSelected: (_) => onChanged(option),
          ),
        );
      }).toList(),
    );
  }

  void _showExitDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Exit Game"),
          content: const Text("Are you sure you want to exit?"),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text("No"),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                exit(0); // Exit the app
              },
              child: const Text("Yes"),
            ),
          ],
        );
      },
    );
  }

  void _showInstructionsDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Game Instructions", style: TextStyle(fontSize: 19)),
          content: const Text(
            "• Flip cards to find matching pairs\n"
                "• Remember card positions\n"
                "• Match all pairs before time runs out\n"
                "• Earn 10 points for each match",
            textAlign: TextAlign.left,
            style: TextStyle(fontSize: 17),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text("Close", style: TextStyle(fontSize: 17)),
            ),
          ],
        );
      },
    );
  }
}
